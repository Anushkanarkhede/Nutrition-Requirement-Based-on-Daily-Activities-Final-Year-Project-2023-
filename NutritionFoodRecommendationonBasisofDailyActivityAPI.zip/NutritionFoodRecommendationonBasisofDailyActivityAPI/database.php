<?php
$con = mysqli_connect("localhost","root","","nutritionfoodrecommendationonbasisofdailyactivitydb") or die('unable to connect');
?>