<?php
$con = mysqli_connect("localhost","root","","nutritionfoodrecommendationonbasisofdailyactivitydb") or die('Unable to Connect');
?>