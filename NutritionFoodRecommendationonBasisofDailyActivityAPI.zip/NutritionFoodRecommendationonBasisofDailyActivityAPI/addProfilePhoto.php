<?php
require_once("database.php");
define('UPLOAD_PATH', 'images/');

if(isset($_FILES['pic']['name']) && isset($_POST['tags'])){
 
 //uploading file and storing it to database as well 
 try{
 move_uploaded_file($_FILES['pic']['tmp_name'], UPLOAD_PATH . $_FILES['pic']['name']);

 $filename=$_FILES['pic']['name'];
 
 $sql="update register_user set profile_pic='".$filename."' where id=".$_POST['tags']."";
 $result=mysqli_query($con,$sql);
 
 if(mysqli_affected_rows($con) >0 )
 {
 $response['error'] = false;
 $response['message'] = 'File uploaded successfully';
 }else{
 throw new Exception("Could not upload file");
 }
 }catch(Exception $e){
 $response['error'] = true;
 $response['message'] = 'Could not upload file';
 }
 
 }else{
 $response['error'] = true;
 $response['message'] = "Required params not available";
 }

 echo json_encode($response);

?>