<?php
require_once("database.php");
  mysqli_set_charset($con,"utf8");
  $nutrition_id = $_POST['nutrition_id'];
$sql="SELECT book_my_appointment.id,register_user.name, register_user.mobile_no, register_user.email_id, register_user.age,register_user.gender,register_user.diet,register_user.city, register_user.marrital_status,book_my_appointment.problem,book_my_appointment.booking_date,book_my_appointment.booking_time FROM book_my_appointment INNER JOIN register_user ON book_my_appointment.customer_id=register_user.id where book_my_appointment.nutrition_id = '$nutrition_id'";

$result=array();

$data=mysqli_query($con,$sql);

while($row=mysqli_fetch_array($data))
{
	array_push($result,array('id'=>$row[0],'customer_name' => $row[1],'customer_mobile_no' => $row[2],'customer_email_id'=>$row[3],'customer_age'=>$row[4],'customer_gender'=>$row[5],'customer_diet'=>$row[6],'customer_city'=>$row[7],'customer_marrital_status'=>$row[8],'customer_problem'=>$row[9],'customer_date'=>$row[10],'customer_time'=>$row[11]));
}
echo json_encode(array('getMyBooking'=>$result));

mysqli_close($con);

?>
