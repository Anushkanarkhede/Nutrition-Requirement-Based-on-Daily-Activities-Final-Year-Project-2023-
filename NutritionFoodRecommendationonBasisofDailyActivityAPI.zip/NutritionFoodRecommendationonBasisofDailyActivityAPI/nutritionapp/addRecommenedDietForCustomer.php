<?php
require_once("database.php");

$id = $_POST['id'];
$what_to_eat = $_POST['what_to_eat'];
$what_to_avoid = $_POST['what_to_avoid'];


$sql = "update request_for_diet set status ='Active', what_to_eat = '$what_to_eat', what_to_avoid='$what_to_avoid' where id = '$id'";

$result = mysqli_query($con,$sql);

if ($result > 0) {
	$response['success'] = 1; 
	// code...
}
else
{
$response['sucess'] = 0;
}

echo json_encode($response);

?>