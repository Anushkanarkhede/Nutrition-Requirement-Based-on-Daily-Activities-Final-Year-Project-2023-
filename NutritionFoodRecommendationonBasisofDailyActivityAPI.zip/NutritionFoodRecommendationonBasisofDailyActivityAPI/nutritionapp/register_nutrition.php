<?php
require_once("database.php");
$name=$_POST['name'];
$mobile_no=$_POST['mobile_no'];
$email_id=$_POST['email_id'];
$address=$_POST['address'];
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$specialist=$_POST['specialist'];
$qualification=$_POST['qualification'];
$achievement=$_POST['achievement'];
$username=$_POST['username'];
$password=$_POST['password'];


$sql="insert into register_nutrition(name,mobile_no,email_id,address,country,state,city,specialist,qualification,achievement,username,password) values('$name','$mobile_no','$email_id','$address','$country','$state','$city','$specialist','$qualification','$achievement','$username','$password')";
$result=mysqli_query($con,$sql);
if($result>0)
{
$response['success']=1;
$response['lastinsertedid']= mysqli_insert_id($con);
}

else
{
	$response['success']=0;
}
echo json_encode($response);

?>