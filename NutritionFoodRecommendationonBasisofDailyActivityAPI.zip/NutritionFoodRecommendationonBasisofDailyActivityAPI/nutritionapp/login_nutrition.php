<?php
require_once("database.php");
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "select id,image,name,mobile_no,email_id,address,country,state,city,specialist,qualification,achievement,username, password from register_nutrition where username = '$username' and password = '$password'";

$result = mysqli_query($con,$sql);
if ($row = mysqli_fetch_array($result)) {
	$response['success'] = 1;
	$response['id'] = $row['id'];
	$response['image'] = $row['image'];
	$response['name'] = $row['name'];
	$response['mobile_no'] = $row['mobile_no'];
	$response['email_id'] = $row['email_id'];
	$response['address'] = $row['address'];
	$response['country'] = $row['country'];
	$response['state'] = $row['state'];
	$response['city'] = $row['city'];
	$response['specialist'] = $row['specialist'];
	$response['qualification'] = $row['qualification'];
	$response['achievement'] = $row['achievement'];
	$response['username'] = $row['username'];

}
else {
	$response[success] = 0;
}
echo json_encode($response);
?>