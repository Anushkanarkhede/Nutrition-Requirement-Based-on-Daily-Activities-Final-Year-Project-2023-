<?php
$con = mysqli_connect("localhost","root","","nutritiondecisivesystemdb") or die('Unable to Connect');
?>